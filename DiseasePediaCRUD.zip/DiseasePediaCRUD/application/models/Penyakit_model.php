<?php
class Penyakit_model extends CI_model
{

	public function getAllPenyakit()
	{
		return $query = $this->db->get('penyakit')->result_array();
	}

	public function getAllRumahSakit()
	{
		return $query = $this->db->get('rumahsakit')->result_array();
	}

	public function tambahDataPenyakit()
	{
		$data = [
			
			"noRS" => $this->input->post('noRS', true),
			"nama" => $this->input->post('nama', true),
			"deskripsi" => $this->input->post('deskripsi', true),
			"gejala" => $this->input->post('gejala', true),
			"pencegahan" => $this->input->post('pencegahan', true),

		];
		$this->db->insert('penyakit',$data);
	}

	public function hapusDataPenyakit($id)
	{

		$this->db->where('id',$id);
		$this->db->delete('penyakit');
	}

	public function getPenyakitById($id)
	{
		return $this->db->get_where('penyakit',['id' => $id])->row_array();

	}

	public function getRSById($id)
	{
		$data = $this->db->get_where('penyakit',['id' => $id])->row_array();
		return $this->db->get_where('rumahsakit',['noRS' => $data['noRS']])->row_array();
	}

	public function ubahDataPenyakit()
	{
		$data = [
			"noRS" => $this->input->post('namaRS', true),
			"nama" => $this->input->post('nama', true),
			"deskripsi" => $this->input->post('deskripsi', true),
			"gejala" => $this->input->post('gejala', true),
			"pencegahan" => $this->input->post('pencegahan', true),
		];
		$this->db->where('id',$this->input->post('id'));
        $this->db->update('penyakit',$data);
	}

	public function cariDataPenyakit()
	{


		$keyword = $this->input->post('cari', true);
        $this->db->like('nama',$keyword);
        $this->db->or_like('deskripsi',$keyword);
        $this->db->or_like('gejala',$keyword);
        $this->db->or_like('pencegahan',$keyword);
		return $this->db->get('penyakit')->result_array();

	}

}
