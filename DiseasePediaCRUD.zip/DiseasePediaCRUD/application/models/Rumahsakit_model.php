<?php
class Rumahsakit_model extends CI_model
{

	public function getAllRumahSakit()
	{
		return $query = $this->db->get('rumahsakit')->result_array();
	}

	public function tambahDataRumahSakit()
	{
		$data = [
			
			"namaRS" => $this->input->post('namaRS', true),
			"alamat" => $this->input->post('alamat', true),
			"kontak" => $this->input->post('kontak', true),

		];
		$this->db->insert('rumahsakit',$data);
	}

	public function hapusDataRumahSakit($noRS)
	{

		$this->db->where('noRS',$noRS);
		$this->db->delete('rumahsakit');
	}

	public function getRSById($noRS)
	{
		return $this->db->get_where('rumahsakit',['noRS' => $noRS])->row_array();

	}

	public function ubahDataRumahSakit()
	{
		$data = [
			"noRS" => $this->input->post('noRS', true),
			"namaRS" => $this->input->post('namaRS', true),
			"alamat" => $this->input->post('alamat', true),
			"kontak" => $this->input->post('kontak', true),
			
		];
		$this->db->where('noRS',$this->input->post('noRS'));
        $this->db->update('rumahsakit',$data);
	}

	public function cariDataRumahSakit()
	{
		$keyword = $this->input->post('cari', true);
        $this->db->like('namaRS',$keyword);
		return $this->db->get('rumahsakit')->result_array();

	}

	public function isClear($noRS)
	{
		$data = $this->getRSById($noRS);
		$query= $this->db->get_where('penyakit',['noRS' => $data['noRS']]);


		if($query->num_rows() > 0){
			return FALSE;
		}
		else {
			return TRUE;
		}
	}
}
