<?php
class DaftarRumahSakit extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Rumahsakit_model');
		$this->load->library('form_validation');
	}


	public function index()
	{

		$data['judul'] = 'Daftar Rumah Sakit';
		$data['rumahsakit'] = $this->Rumahsakit_model->getAllRumahSakit();
		if ($this->input->post('cari')) {
			$data['rumahsakit'] = $this->Rumahsakit_model->cariDataRumahSakit();
		}
		$this->load->view('templates/header2', $data);
		$this->load->view('daftarrumahsakit/index', $data);
	}

	public function tambah()
	{
		$data['judul'] = 'Form Tambah Data Rumah Sakit';
		$data['rumahsakit'] = $this->Rumahsakit_model->getAllRumahSakit();

		
		$this->form_validation->set_rules('namaRS','Nama Rumah Sakit','required');
		$this->form_validation->set_rules('alamat','Alamat Rumah Sakit','required');
        $this->form_validation->set_rules('kontak','Kontak Rumah Sakit','required');
        


		
        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
			$this->load->view('daftarrumahsakit/tambah');
        }
        else{
            $this->Rumahsakit_model->tambahDataRumahSakit();
            $this->session->set_flashdata('flash','data berhasil ditambah');
            redirect('daftarrumahsakit');
        }
		
	}

	public function hapus($noRS)
	{

		if($this->Rumahsakit_model->isClear($noRS)) {
			$this->Rumahsakit_model->hapusDataRumahSakit($noRS);
		    $this->session->set_flashdata('flash','Data Rumah Sakit berhasil dihapus');
		}
		else {
		    $this->session->set_flashdata('flash','Data Penyakit harus dihapus terlebih dahulu');
		}
		
		redirect('daftarrumahsakit');

	}

	public function ubah($noRS)
	{
		$data['judul'] = 'Form Ubah Data Rumah Sakit';
		$data['rumahsakit'] = $this->Rumahsakit_model->getRSById($noRS);

		$this->form_validation->set_rules('namaRS','Nama Rumah Sakit','required');
		$this->form_validation->set_rules('alamat','Alamat Rumah Sakit','required');
        $this->form_validation->set_rules('kontak','Kontak Rumah Sakit','required');
        

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
			$this->load->view('daftarrumahsakit/ubah');
        }
        else{
            $this->Rumahsakit_model->ubahDataRumahSakit();
            $this->session->set_flashdata('flash','Data berhasil di update');
            redirect('daftarrumahsakit');
        }
	}

}
