<?php
class DaftarPenyakit extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Penyakit_model');
		$this->load->library('form_validation');
	}


	public function index()
	{

		$data['judul'] = 'Daftar Penyakit';
		$data['Penyakit'] = $this->Penyakit_model->getAllPenyakit();
		if ($this->input->post('cari')) {
			$data['Penyakit'] = $this->Penyakit_model->cariDataPenyakit();
		}
		$this->load->view('templates/header2', $data);
		$this->load->view('daftarpenyakit/index', $data);
	}

	public function tambah()
	{
		$data['judul'] = 'Form Tambah Data Penyakit';
		$data['rumahsakit'] = $this->Penyakit_model->getAllRumahSakit();

		
		$this->form_validation->set_rules('noRS','Nomor Rumah Sakit','required');
		$this->form_validation->set_rules('nama','Nama Penyakit','required');
		$this->form_validation->set_rules('deskripsi','Deskripsi penyakit','required');
        $this->form_validation->set_rules('gejala','Gejala','required');
        $this->form_validation->set_rules('pencegahan','Cara Pencegahan','required');


		
        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
			$this->load->view('daftarpenyakit/tambah');
        }
        else{
            $this->Penyakit_model->tambahDataPenyakit();
            $this->session->set_flashdata('flash','data berhasil ditambah');
            redirect('daftarpenyakit');
        }
		
	}

	public function hapus($id)
	{
		
		$this->Penyakit_model->hapusDataPenyakit($id);
		$this->session->set_flashdata('flash','Data Penyakit berhasil dihapus');
		
		redirect('daftarpenyakit');

	}

	public function ubah($id)
	{
		$data['judul'] = 'Form Ubah Data Penyakit';

		$data['penyakit'] = $this->Penyakit_model->getPenyakitById($id);
		$data['rumahsakit'] = $this->Penyakit_model->getAllRumahSakit();

		$this->form_validation->set_rules('namaRS','Nama Rumah Sakit','required');
		$this->form_validation->set_rules('nama','Nama Penyakit','required');
		$this->form_validation->set_rules('deskripsi','Deskripsi penyakit','required');
        $this->form_validation->set_rules('gejala','Gejala','required');
        $this->form_validation->set_rules('pencegahan','Cara Pencegahan','required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header', $data);
			$this->load->view('daftarpenyakit/ubah');
        }
        else{
            $this->Penyakit_model->ubahDataPenyakit();
            $this->session->set_flashdata('flash','Data berhasil di update');
            redirect('daftarpenyakit');
        }
	}

	public function detail($id)
	{
		$data['penyakit'] = $this->Penyakit_model->getPenyakitById($id);
		$data['rumahsakit'] = $this->Penyakit_model->getRSById($id);
		$this->load->view('templates/header', $data);
		$this->load->view('daftarpenyakit/detail');
	}

}
