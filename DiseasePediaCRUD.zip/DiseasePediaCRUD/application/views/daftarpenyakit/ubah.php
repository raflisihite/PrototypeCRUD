<div class="container">
  <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Ubah Data Penyakit
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <input type="hidden" name="id" value="<?= $penyakit['id'] ?>">
                      <div class="form-group">
                        <label for="nama">Nama Penyakit</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= $penyakit['nama']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama') ?>.</small>
                      </div>
                       <div class="form-group">
                        <label for="nama">Deskripsi Penyakit</label>
                            <input type="text" class="form-control" id="deskripsi" name="deskripsi" value="<?= $penyakit['deskripsi']; ?>">
                            <small class="form-text text-danger"><?= form_error('deskripsi') ?>.</small>
                      </div>
                      <div class="form-group">
                        <label for="gejala">Gejala Penyakit</label>
                        <input type="text" class="form-control" id="gejala" name="gejala" value="<?= $penyakit['gejala']; ?>">
                      </div>
                      <div class="form-group">
                        <label for="pencegahan">Cara Pencegahan</label>
                        <input type="text" class="form-control" id="pencegahan" name="pencegahan" value="<?= $penyakit['pencegahan']; ?>">
                      </div>
                      <div class="form-group">
                            <label for="jurusan">Rumah Sakit</label>
                            <select class="form-control" id="namaRS" name="namaRS">
                                <?php foreach ($rumahsakit as $j) : ?>
                                <?php if ($j['noRS'] == $penyakit['noRS']) : ?>
                                <option value="<?= $j['noRS']; ?>" selected><?= $j['namaRS']; ?></option>
                                <?php else : ?>
                                <option value="<?= $j['noRS']; ?>"><?= $j['namaRS']; ?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                      <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>