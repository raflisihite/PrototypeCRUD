<div class="container">
	<div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Tambah Data Penyakit
                </div>
                <div class="card-body">
                    <form action="" method="post">
  						        <div class="form-group">
    						        <label for="nama">Nama Penyakit</label>
    						        <input type="text" class="form-control" id="nama" name="nama">
  						        </div>
                      <div class="form-group">
                        <label for="gejala">Deskripsi Penyakit</label>
                        <input type="text" class="form-control" id="deskripsi" name="deskripsi">
                      </div>
  						        <div class="form-group">
    						        <label for="gejala">Gejala Penyakit</label>
    						        <input type="text" class="form-control" id="gejala" name="gejala">
  						        </div>
  						        <div class="form-group">
    						        <label for="pencegahan">Cara Pencegahan</label>
    						        <input type="text" class="form-control" id="pencegahan" name="pencegahan">
  						        </div>
                      <div class="form-group">
                            <label for="jurusan">Nama Rumah Sakit</label>
                            <select class="form-control" id="noRS" name="noRS">
                                <?php foreach ($rumahsakit as $j) : ?>
                                <option value="<?= $j['noRS']; ?>"><?= $j['namaRS']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
  						        <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah</button>
                    </form>
				        </div>
            </div>
        </div>
  </div>
</div>