<div class="container">
  <br><br><br><br>
  <h1><?= $penyakit['nama']; ?></h1><br>
  	<h4>Deskripsi Penyakit</h4>
  		<p><?= $penyakit['deskripsi']; ?></p><br>
  	<h4>Gejala Penyakit</h4>
  		<p><?= $penyakit['gejala']; ?></p><br>
  	<h4>Pencegahan</h4>
  		<p><?= $penyakit['pencegahan']; ?></p><br>
  	<h4>Rumah Sakit Rujukan</h4>
  		<p><?= $rumahsakit['namaRS']; ?><br>
  		Alamat :<?= $rumahsakit['alamat']; ?><br>
  		Kontak :<?= $rumahsakit['kontak']; ?></p>
</div>