<div class="container">
    <?php if ($this->session->flashdata('flash')) : ?>
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('flash'); ?>.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="row mt-5">
        <div class="col">
            <table class="table mt-5">
                <thead>
                    <tr>
                        <th class="text-center" scope="col">NAMA RUMAH SAKIT</th>
                        <th class="text-center" scope="col">ALAMAT</th>
                        <th class="text-center" scope="col">KONTAK</th>
                        <th class="text-center" scope="col">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php foreach ($rumahsakit as $p) : ?>
                        <td class="text-center"><?= $p['namaRS']; ?></td>
                        <td class="text-center"><?= $p['alamat']; ?></td>
                        <td class="text-center"><?= $p['kontak']; ?></td>
                        <td class="text-center">
                            <a href="<?= base_url(); ?>index.php/DaftarRumahSakit/hapus/<?= $p['noRS'] ?>" class="badge badge-danger float-center" onclick="return confirm('Apakah anda yakin menghapus data ini?');" ?>Hapus</a>
                            <a href="<?= base_url(); ?>index.php/DaftarRumahSakit/ubah/<?= $p['noRS'] ?>" class="badge badge-success float-center" ?>ubah</a>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            <div class="row mt-3">
                <div class="col md-6 text-center mt-5">
                    <a href="<?= base_url(); ?>index.php/DaftarRumahSakit/tambah " class="btn btn-primary">Tambah</a>
                </div>
            </div>
        </div>
    </div>
</div>