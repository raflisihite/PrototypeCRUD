<div class="container">
  <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Ubah Data Rumah Sakit
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <input type="hidden" name="noRS" value="<?= $rumahsakit['noRS'] ?>">
                      <div class="form-group">
                        <label for="nama">Nama Rumah Sakit</label>
                            <input type="text" class="form-control" id="namaRS" name="namaRS" value="<?= $rumahsakit['namaRS']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama') ?>.</small>
                      </div>
                       <div class="form-group">
                        <label for="nama">Alamat Rumah Sakit</label>
                            <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $rumahsakit['alamat']; ?>">
                            <small class="form-text text-danger"><?= form_error('alamat') ?>.</small>
                      </div>
                      <div class="form-group">
                        <label for="gejala">Kontak Rumah Sakit</label>
                        <input type="text" class="form-control" id="kontak" name="kontak" value="<?= $rumahsakit['kontak']; ?>">
                      </div>
                      <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>