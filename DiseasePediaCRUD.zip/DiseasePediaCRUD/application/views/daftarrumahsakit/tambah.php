<div class="container">
	<div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Tambah Data Rumah Sakit
                </div>
                <div class="card-body">
                    <form action="" method="post">
  						        <div class="form-group">
    						        <label for="nama">Nama Rumah Sakit</label>
    						        <input type="text" class="form-control" id="namaRS" name="namaRS">
  						        </div>
                      <div class="form-group">
                        <label for="gejala">Alamat Rumah Sakit</label>
                        <input type="text" class="form-control" id="alamat" name="alamat">
                      </div>
  						        <div class="form-group">
    						        <label for="gejala">Kontak Rumah Sakit</label>
    						        <input type="text" class="form-control" id="kontak" name="kontak">
  						        </div>
  						        <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah</button>
                    </form>
				        </div>
            </div>
        </div>
  </div>
</div>